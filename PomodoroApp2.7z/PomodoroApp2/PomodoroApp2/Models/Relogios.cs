﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PomodoroApp2.Models
{
    public class Relogios
    {

        public int TempoPomodoro { get; set; }

    }
}
